import processing.core.PApplet;

/**
 * Call Map class to initialise PApplet
 */

public class Main {

    public static void main(String[] args) {
        PApplet.main(new String[]{Map.class.getName()});

    }
}
